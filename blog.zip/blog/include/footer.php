


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script type="text/javascript" src="<?php echo $url; ?>admin/assets/jquery-3.5.1.slim.min.js" </script>
< script type = "text/javascript"
src = "<?php echo $url; ?>admin/assets/https://code.jquerpopper.min.js"
</script>
<script type="text/javascript" src="<?php echo $url; ?>admin/assets/bootstrap.min.js" </script>
< /body> < /
html >