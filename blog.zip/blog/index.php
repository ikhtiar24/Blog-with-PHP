<?php 
include('include/header.php'); 
include("admin/include/connect.php");
$conn = connectdb();


// count total post
$sql = "SELECT count(id) as total FROM post";
$result = $conn->query($sql);
$data = mysqli_fetch_assoc($result);

// pagination 
$skip= 0;
$take = 2;
$page =1;


if(isset($_GET['page'])){
    $page = $_GET['page'];
    $skip = ($page-1) * $take;
}

// count total page
// int value used to round the page number for 
$totalpage = intval($data['total'] / $take)+1; 

// LAST INSERT GO FIRST
$sql = "SELECT * FROM post 
ORDER BY id DESC 
LIMIT $skip, $take";

$result = $conn->query($sql);

?>

<div class="container">

    <div class="row clearfix ">
        <div class="col-md-2"> </div>

        <div class="col-md-8 single-post">

            <?php  while($row = mysqli_fetch_assoc($result)) { ?>

            <div class="post">
                <h2 class="">
                    <a href="<?php echo $url; ?>/single.php?id=<?php echo $row['id']; ?>">
                        <?php echo $row['title']; ?>
                    </a>
                </h2>


                <div class="row">

                    <div class="col-md-3">

                        <img src="admin/<?php echo $row['image']; ?>" alt="">

                    </div>
                    <div class="col-md-9">
                        <P> <?php echo substr($row['description'],0, 250); // for limited word use substr ?></P>
                    </div>

                </div>

            </div>

            <?php } ?>
            <!--      showing page   -->

            <div style="margin-bottom:20px">
                Page <?php echo $page; ?> of <?php echo $totalpage; ?>
                </>

                <!--      For pagination     -->
                <div class="row clearfix ">
                    <div class="col-md-3">
                        <?php if ($page > 1) { ?>

                        <a href="<?php echo $url ?>index.php?page=<?php echo $page - 1 ?> ">
                            << Previous </a>
                                <?php } ?>

                    </div>

                    <div class="col-md-3">
                        <div class="text-center">
                            <?php for($i =1; $i<=$totalpage; $i++) { ?>

                            <a href="<?php echo $url ?>index.php?page=<?php echo $i ?> " class="pagination">
                                <?php echo $i; ?>

                            </a>
                            <?php } ?>
                        </div>

                    </div>
                    <div class="col-md-3 ">
                        <div class="text-right">
                            <?php if ($totalpage > $page) { ?>

                            <a href="<?php echo $url ?>index.php?page=<?php echo $page + 1 ?> "> Next >> </a>
                            <?php } ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <?php include('include/footer.php'); ?>