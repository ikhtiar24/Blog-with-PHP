<?php 
 function connectdb(){
    $conn = new mysqli('localhost', 'root', '', 'blog');

    return $conn;
 }

 


?>