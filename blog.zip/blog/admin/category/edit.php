<?php 
if(isset($_GET['id'])){
    
    $id = $_GET['id'];
    include('../include/connect.php');
    $conn = connectdb();
    $sql = "SELECT * FROM category WHERE id ='$id' ";
    $result= $conn-> query($sql);
    $row = mysqli_fetch_assoc($result);
   
}

?>
<?php include('../include/header.php'); ?>

<a class ="btn btn-success" href ="index.php"> Back </a>
<br> <br>
<div class="content">

    <h2> Edit Title </h2>

    <form action ="update.php?id=<?php echo $row['id']; ?>" method="POST">
  <div class="form-group">
    <label for="title"> Title </label>
    <input type="text" class="form-control" id="title" value= "<?php echo $row['title']; ?>" 
    name="title" placeholder ="Title">
  </div>
  
  <input type="submit" class="btn btn-primary" name ="submit" value = "submit">
</form>
   

</div>


<?php include('../include/footer.php'); ?>