
<?php 
if(isset($_POST['submit'])){
    
   $title = $_POST['title'];
   $id = $_GET['id'];
    include('../include/connect.php');
    $conn = connectdb();
    $sql = "UPDATE category SET title ='$title' WHERE id = '$id' ";
    $result= $conn-> query($sql);
    header("Location: index.php");
} 

?>