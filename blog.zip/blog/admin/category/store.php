
<?php 
if(isset($_POST['title'])){
    
    echo $title = $_POST['title'];
    include('../include/connect.php');
    $conn = connectdb();
    $sql = "INSERT INTO category VALUES(NULL, '$title')";
    $result= $conn-> query($sql);
    header("Location: index.php");
}

?>