
<?php 
if(isset($_GET['id'])){
    
    $id = $_GET['id'];
    include('../include/connect.php');
    $conn = connectdb();
    $sql = "DELETE FROM category  WHERE id = '$id' ";
    $result= $conn-> query($sql);
    header("Location: index.php");
}

?>