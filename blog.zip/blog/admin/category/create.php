<?php include('../include/connect.php'); ?>

<?php 

$conn = connectdb();
$sql = "SELECT * FROM category";
$result= $conn-> query($sql);


?>

<?php include('../include/header.php'); ?>

<a class ="btn btn-success" href ="index.php"> Back </a>
<br> <br>
<div class="content">

    <h2> Add New Categories </h2>


    <form action ="store.php" method="POST">
  <div class="form-group">
    <label for="title"> Title </label>
    <input type="text" class="form-control" id="title" name ="title" placeholder ="Title">
    
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
   

</div>


<?php include('../include/footer.php'); ?>