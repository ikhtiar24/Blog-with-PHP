
<?php 
    $title = $_POST['title'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $category_id = $_POST['category_id'];
    $image =$_POST['image'];

    //start image upload 
    $rand = rand(1, 9999999); // automatically generated number for image
   
    $image = 'uploads/'. $rand . $_FILES['image']['name'];
    $upload = '../uploads/'. $rand. $_FILES['image']['name'];
    move_uploaded_file($_FILES['image']['tmp_name'], $upload);

    // end image upload

    include('../include/connect.php');
    $conn = connectdb();
   
    $sql = "INSERT INTO post VALUES(NULL, $category_id, '$title', '$description', '$image', '$date' )";
    $result= $conn-> query($sql);
    header("Location: index.php");

?>