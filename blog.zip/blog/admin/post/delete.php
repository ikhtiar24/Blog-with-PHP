<?php
 $id =$_GET['id'];
 include('../include/connect.php');
 $conn = connectdb();
 // delete data with file

 $sql1 = "SELECT * FROM  post WHERE id= '$id' ";
 $result= $conn-> query($sql1);
 $data = mysqli_fetch_assoc($result);
 $image_location = '../' . $data['image'];
 
 if(file_exists( $image_location)){
     unlink( $image_location);

 }else{
     echo "NO file found";
     }
// end of delete data with file

 $sql = "DELETE FROM  post WHERE id= '$id'";
 $res= $conn-> query($sql);
 header("Location: index.php");

?>