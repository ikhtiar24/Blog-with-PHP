<?php
 include('../include/connect.php');
 $conn = connectdb();

 $id = $_GET['id']; 
 $title = $_POST['title'];
 $description = $_POST['description'];
 $date = $_POST['date'];
 $category_id = $_POST['category_id'];


 // to get previous data
 $sql = "select post.*, category.title as categorytitle
 from post INNER JOIN category ON post.category_id = category.id 
 where post.id = '$id';";
 $result= $conn-> query($sql);
 $data = mysqli_fetch_assoc($result);


 
 


if(!empty($_FILES['image']['name'])){

    // upload new image 

    $image = 'uploads/'. $rand . $_FILES['image']['name'];
    $upload = '../uploads/'. $rand. $_FILES['image']['name'];
    move_uploaded_file($_FILES['image']['tmp_name'], $upload);
    
    // check already stored image in database. if stored delete image and upload new image

    if(!empty($data['image'] )){
        unlink('../' . $data['image']); // delete image
    }

}
    // for update image 
    $updatesql = " UPDATE post SET title='$title', description ='$description', date ='$date', 
    category_id ='$category_id', image = '$image' WHERE  id = '$id' ";

    $res = $conn->query($updatesql);
    header("Location: index.php");

?>