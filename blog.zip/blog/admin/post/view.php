<?php include('../include/connect.php'); ?>

<?php 

// show single post
$id = $_GET['id']; 
$conn = connectdb();
$sql = "select post.*, category.title as categorytitle
from post INNER JOIN category ON post.category_id = category.id 
where post.category_id = '$id';";
$result= $conn-> query($sql);
$data = mysqli_fetch_assoc($result);

?>

<?php include('../include/header.php'); ?>

<a class="btn btn-success" href="index.php"> Back </a>
<br> <br>
<div class="content">

    <h2>  Post Details </h2>
    <table class="table">
        <tr>
            <th> Title: </th>
            <td> <?php echo $data['title'] ?> </td>
        </tr>
        <tr>
            <th> Category: </th>
            <td> <?php echo $data['categorytitle'] ?> </td>
        </tr>
        <tr>
            <th> Description: </th>
            <td> <?php echo $data['description'] ?> </td>
        </tr>
        <tr>
            <th> Image: </th>
            <td> <img src ="../<?php echo $data['image'] ?>" width ="250">  </td>
        </tr>
        <tr>
            <th> Date: </th>
            <td> <?php echo $data['date'] ?> </td>
        </tr>

    </table>



</div>

<?php include('../include/footer.php'); ?>