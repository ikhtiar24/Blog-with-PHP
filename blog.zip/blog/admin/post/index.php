<?php include('../include/connect.php'); ?>

<?php 

$conn = connectdb();
$sql = "SELECT * FROM post";
$result= $conn-> query($sql);


?>

<?php include('../include/header.php'); ?>

<a class ="btn btn-success" href ="create.php"> Add Post  </a>
<br> <br>
<div class="content">

    <h2> Post List </h2>
    <table class="table table-bordered">
        <thead>
            <th> # </th>
            <th> Title </th>
            <th> Description </th>
            <th> Image </th>
            <th> Date </th>
            <th> Action </th>
        </thead>
        <?php while($row = mysqli_fetch_assoc($result)) {  ?>
        <tr>
            <td> <?php echo $row['id']; ?> </td>
            <td> <?php echo $row['title']; ?> </td>
            <td> <?php echo $row['description']; ?></td>
            <td> <img src = "../<?php echo $row['image']; ?>" width ="100"> </td>
            <td> <?php echo $row['date']; ?></td>
            <td>
                <a class="btn btn-success" href ="view.php?id=<?php echo $row['category_id'] ?>"> View</a>
                <a class="btn btn-info"  href ="edit.php?id=<?php echo $row['id'] ?> "> Edit </a>
                <a class="btn btn-danger"  href ="delete.php?id=<?php echo $row['id']; ?>" 
                onclick="return confirm('Are you sure?')" > Delete </a>

            </td>
        </tr>

      <?php  } ?>

    </table>
    
    

</div>


<?php include('../include/footer.php'); ?>