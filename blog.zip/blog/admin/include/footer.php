</div>


</div>

</div>
</div>

<div class="container-fluid footer bg-warning">
    <div class="container">
        <div class="row clearfix">
            <div class="col-md-4">
                Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying
                out print, graphic or web designs. The passage is attributed to an unknown
                typesetter in the 15th century who is thought to have scrambled parts of
                Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.

            </div>

        </div>
    </div>

</div>





<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script type="text/javascript" src="<?php echo $url; ?>assets/jquery-3.5.1.slim.min.js" </script>
< script type = "text/javascript"
src = "<?php echo $url; ?>assets/https://code.jquerpopper.min.js"
</script>
<script type="text/javascript" src="<?php echo $url; ?>assets/bootstrap.min.js" </script>
< /body> < /
html >