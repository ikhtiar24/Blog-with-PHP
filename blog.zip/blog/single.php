<?php 
include('include/header.php'); 
include("admin/include/connect.php");
$conn = connectdb();

$id = $_GET['id'];

if(! $_GET['id']){
   header("Location:index.php");
}


$sql = "SELECT * FROM post 
where id =$id ";

$result= $conn-> query($sql);
$data = mysqli_fetch_assoc($result);


?>
<!-- view single post  -->

<div class="container">

    <div class="row clearfix">

        <div class="col-md-2"> </div>

        <div class="col-md-8">

            <div class="single-post">
                <h1> <?php echo $data['title']; ?> </h1>

                                                                 <div style="margin-bottom:10px">

                    <?php 
                  $catit = $data['category_id'];
                  $sql1 = "SELECT * FROM category 
                   where id =$catit ";

                    $res= $conn-> query($sql1);
                    $data1 = mysqli_fetch_assoc($res);
                  echo $data1['title']; ?>
                </div>

                                                      <div class="row">

                    <div class="col-md-12 test2">

                        <img src="admin/<?php echo $data['image']; ?>" alt="">

                    </div>

                    <div class="col-md-12 test">
                        <?php echo $data['description']; // for limited word use substr ?>
                    </div>

                </div>

            </div>

        </div>


    </div>


</div>


<?php include('include/footer.php'); ?>